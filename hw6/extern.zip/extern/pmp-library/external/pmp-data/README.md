# pmp-data

* `suzanne.obj` Was created using Blender (original model from Willem-Paul van Overbruggen)
* `bunny.off` The Bunny model is courtesy of The Stanford 3D Scanning Repository (Marc Levoy)
* `fandisk.off` The Fandisk model is courtesy of Hugues Hoppe, Microsoft Research
* `armadillo_low.xyz` The Armadillo model is courtesy of The Stanford 3D Scanning Repository
* `fandisk_quads.off` The quad mesh of the Fandisk is courtesy of David Bommes
* `beetle.off` The Beetle model is courtesy of Ivan Sutherland ([history](http://www.cs.utah.edu/docs/misc/Uteapot03.pdf))
* `amo.off` The AmO model is courstesy of Mario Botsch
* `fairing-cross.off` is courstesy of Mario Botsch
* `elephant.off` The Elephant model is provided courtesy of INRIA by the AIM@SHAPE Shape Repository.
